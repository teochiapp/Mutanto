
const languageTxt = {
    "es":["Debes ingresar ", "tu nombre", "tu e-mail", "una descripción de tu proyecto","El archivo debe ser menor a 25 MB","Ingresa un e-mail válido"],
    "en":["You must enter ", "your name", "your email", "something about your project","File must be smaller than 25MB","Enter a valid email address"],
}

const fileInput = document.getElementById('muntanto__contacto-form-input-file');

const divFile = document.querySelector(".muntanto__contacto-form-err-file");
const divName = document.querySelector('.muntanto__contacto-form-err-name');
const divEmail = document.querySelector('.muntanto__contacto-form-err-email');
const divComment = document.querySelector('.muntanto__contacto-form-err-comments');

let arrayFlag = [0, 0, 0];

fileInput.addEventListener("change", function() {
  const fileMaxSize = 25600;
  let files = fileInput.files;
  let fileSize = files[0].size;
  let fileInKb = Math.round((fileSize / 1024));
  if (fileInKb > fileMaxSize) {
    divFile.innerHTML = "👆 " +  languageTxt[language][4];
  } else {
    divFile.innerHTML = "";
  }
});


document.querySelector("#sendButtonM").addEventListener("click", function() {
  sendContent () ;
});

document.querySelector("#sendButton").addEventListener("click", function() {
  sendContent () ;
});


function sendContent () {
  let name = document.querySelector("#muntanto__contacto-form-input-name").value;
  let email = document.querySelector("#muntanto__contacto-form-input-email").value;
  let comment = document.querySelector("#muntanto__contacto-form-input-comments").value;
  let attachedFile = document.querySelector("#muntanto__contacto-form-input-file").files[0];

  checkEmptyField(name, divName, languageTxt[language][1], 0);
  checkEmptyField(email, divEmail, languageTxt[language][2], 1);
  checkEmptyField(comment, divComment, languageTxt[language][3], 2);

  if (arrayFlag[1] != 1) {
    if (validator.isEmail(email)) {
      arrayFlag[1] = 0;
      divEmail.innerHTML = "";
    } else {
      arrayFlag[1] = 2;
      divEmail.innerHTML = "👆 "+languageTxt[language][5];
      divEmail.classList.toggle("scale-in-ver-bottom");
    }
  }

  if (arrayFlag[0] == 0 && arrayFlag[1] == 0 && arrayFlag[2] == 0) {
    document.querySelector(".mutanto__contacto-form-inputs").classList.add("hidden");
    document.querySelector(".mutanto__contacto-form-ajax").classList.add("visible");
    document.querySelector("#sendButtonM").classList.add("hidden");
    document.querySelector("#sendButton").classList.add("hidden");
    let xhr = new XMLHttpRequest();
    let formData = new FormData();
    formData.append("muntanto__contacto-form-input-name", name);
    formData.append("muntanto__contacto-form-input-email", email);
    formData.append("muntanto__contacto-form-input-comments", comment);
    formData.append("muntanto__contacto-form-input-file", attachedFile);
    xhr.open("POST", "_send.php", true);
    xhr.onload = function() {
      if (xhr.status === 200) {
        document.querySelector(".dots-container").classList.add("hidden");
        if (getWindowWidth()<mobiles) {
          document.querySelector(".mutanto__contacto-form-ajax").classList.add("mutanto__contacto-form-ajaxM");
          document.querySelector(".mutanto__contacto-form-table-form").classList.add("mutanto__contacto-form-ajaxM");
          
        }
        document.querySelector(".mutanto__contacto-form-ajax-txt").innerHTML = xhr.responseText;
      } else {
        document.querySelector(".mutanto__contacto-form-ajax-txt").innerHTML = xhr.status;
      }
    };
    xhr.send(formData);
  }
}

function checkEmptyField(inputField, inputDiv, textShow, arrayIndex) {
  if (validator.isEmpty(inputField)) {
    inputDiv.innerHTML = "👆 "+ languageTxt[language][0]  + textShow;
    inputDiv.classList.toggle("scale-in-ver-bottom");
    arrayFlag[arrayIndex] = 1;
  } else {
    inputDiv.innerHTML = "";
    arrayFlag[arrayIndex] = 0;
  }
}