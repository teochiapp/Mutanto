$(document).ready(function(){

    if (getWindowWidth() >= mobiles && getWindowWidth() <= destktop) {
     
        $(".owl-carousel").owlCarousel({
            center: true,
            items:1.8,
            loop:true,
            margin:10,
        });
    }

    if (getWindowWidth() < mobiles) {
        
        $(".owl-carousel").owlCarousel({
            items:1.3,
            loop:true,
            nav:false,
            center:true,
            margin:10,
            
        });
    }


});