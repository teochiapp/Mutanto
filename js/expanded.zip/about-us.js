//Set Staff Pics Manager

const mutantoStaffPics1 = document.querySelectorAll(".mutanto__elements-staffPic-images .mutanto__elements-staffPic-images-1");
const mutantoStaffPics2 = document.querySelectorAll(".mutanto__elements-staffPic-images .mutanto__elements-staffPic-images-2");
const mutantoStaffPicsBackground = document.querySelectorAll(".mutanto__elements-staffPic-images-background");
const mutantoStaffPic = document.querySelectorAll(".mutanto__elements-staffPic");


//Load About Us Page
document.addEventListener("DOMContentLoaded", function () {

    mutantoStaffPics2.forEach(e => {
        e.classList.add("mutanto__elements-staffPic-images-back");
    })

    mutantoStaffPicsBackground.forEach(e => {
        e.classList.add("mutanto__elements-staffPic-images-background-hidden");
    })

    if (getWindowWidth() >= destktop) {
        
        mutantoStaffPic.forEach(e => {
            const startPic = e.querySelector(".mutanto__elements-staffPic-images");
            startPic.addEventListener("mouseenter", function () {
                e.style.zIndex = "2";
                const imagenTop = e.querySelector(".mutanto__elements-staffPic-images-1");
                const imagenDown = e.querySelector(".mutanto__elements-staffPic-images-2");

                imagenTop.classList.add("mutanto__elements-staffPic-hidden");
                imagenDown.classList.remove("mutanto__elements-staffPic-visible");
                imagenDown.classList.remove("mutanto__elements-staffPic-images-back");
                imagenDown.classList.add("mutanto__elements-staffPic-visible");
                
                const elmentToShow = e.querySelector(".mutanto__elements-staffPic-images-background");
                elmentToShow.classList.remove("mutanto__elements-staffPic-images-background-hidden");
                elmentToShow.classList.add("mutanto__elements-staffPic-images-background-visible");
            });
        });
        
        mutantoStaffPic.forEach(e => {
            const startPic = e.querySelector(".mutanto__elements-staffPic-images");
            startPic.addEventListener("mouseleave", function () {
                e.style.zIndex = "1";

                const imagenTop = e.querySelector(".mutanto__elements-staffPic-images-1");
                const imagenDown = e.querySelector(".mutanto__elements-staffPic-images-2");

                imagenTop.classList.remove("mutanto__elements-staffPic-hidden");
                //imagenTop.classList.add("mutanto__elements-staffPic-visible");
                imagenDown.classList.remove("mutanto__elements-staffPic-visible");
                imagenDown.classList.add("mutanto__elements-staffPic-images-back");

                let elmentToHidde = e.querySelector(".mutanto__elements-staffPic-images-background");
                elmentToHidde.classList.remove("mutanto__elements-staffPic-images-background-visible");
                elmentToHidde.classList.add("mutanto__elements-staffPic-images-background-hidden");
        
            });
        })
        
    }

    if (getWindowWidth() >= mobiles && getWindowWidth() <= tables) {
        mutantoStaffPic.forEach(e => {
            const startPic = e.querySelector(".mutanto__elements-staffPic-images");
            startPic.addEventListener("click", function () {
                let elmentToShow = e.querySelector(".mutanto__elements-staffPic-images-background");
                if (elmentToShow.classList.contains("mutanto__elements-staffPic-images-background-visible") != true) {
                    e.style.zIndex = "2";
                    elmentToShow.classList.remove("mutanto__elements-staffPic-images-background-hidden");
                    elmentToShow.classList.add("mutanto__elements-staffPic-images-background-visible");
                    startPic.querySelector(".mutanto__elements-staffPic-images-2").classList.remove("mutanto-services___hide");
                    startPic.querySelector(".mutanto__elements-staffPic-images-2").classList.add("mutanto__elements-staffPic-images-back");
                } else {
                    e.style.zIndex = "1";
                    elmentToShow.classList.remove("mutanto__elements-staffPic-images-background-visible");
                    elmentToShow.classList.add("mutanto__elements-staffPic-images-background-hidden");
                    startPic.querySelector(".mutanto__elements-staffPic-images-2").classList.remove("mutanto__elements-staffPic-images-back");
                    startPic.querySelector(".mutanto__elements-staffPic-images-2").classList.add("mutanto-services___hide");
                }
            });
        });

        mutantoStaffPic.forEach(e => {
            const startPic = e.querySelector(".mutanto__elements-staffPic-images");
            startPic.addEventListener("mouseleave", function () {
                e.style.zIndex = "1";
                let elmentToHidde = e.querySelector(".mutanto__elements-staffPic-images-background");
                elmentToHidde.classList.remove("mutanto__elements-staffPic-images-background-visible");
                elmentToHidde.classList.add("mutanto__elements-staffPic-images-background-hidden");
            });
        })
    }

    if (getWindowWidth() <= mobiles ) {
        mutantoStaffPic.forEach(e => {
            let elmentToShow = e.querySelector(".mutanto__elements-staffPic-images-background");
            elmentToShow.classList.remove("mutanto__elements-staffPic-images-background-hidden");
            elmentToShow.classList.add("mutanto__elements-staffPic-images-background-visible");
        });
    }

});


window.addEventListener('progressEvent', (e) => {
       
    const { target, way, from } = e.detail;
    //console.log(way);
    if (way == "enter") {
      document.querySelector("main").classList.remove("whiteTransition");
      document.querySelector(".header").classList.remove("whiteTransition");
      document.querySelector("main").classList.add("blackTransition");
      document.querySelector(".header").classList.add("blackTransition");
      
     if ( getWindowWidth() >= destktop) {
        document.querySelector(".header").style.height = "149px";
     } else if (getWindowWidth() <= mobiles) {
        document.querySelector(".header").style.height = "90px";
     }

      document.querySelector(".header").style.zIndex = "2";
      
      document.querySelector(".header__mutanto-logo-txt img").src = "/img/muntanto-logo-text-uix-ux-web-desing.svg";
      document.querySelector(".header__mutanto-logo-txt-dark-mode").style.display = "none";

      document.querySelector(".mutanto-element__animated-figure.prefooter").style.filter = "invert(92%) sepia(0%) saturate(7486%) hue-rotate(78deg) brightness(112%) contrast(100%)";


    } else if (way == "leave") {
      document.querySelector("main").classList.remove("blackTransition");
      document.querySelector(".header").classList.remove("blackTransition");
      document.querySelector("main").classList.add("whiteTransition");
      document.querySelector(".header").classList.add("whiteTransition");
      if ( getWindowWidth() >= destktop) {
        document.querySelector(".header").style.height = "149px";
     } else if (getWindowWidth() <= mobiles) {
        document.querySelector(".header").style.height = "80px";
     }
      document.querySelector(".header__mutanto-logo-txt-dark-mode").style.display = "none";
      document.querySelector(".header__mutanto-logo-txt img").src = "/img/muntanto-logo-dark-mode-text-uix-ux-web-desing.svg";
      document.querySelector(".mutanto-element__animated-figure.prefooter").style.filter = "invert(0%) sepia(0%) saturate(7475%) hue-rotate(168deg) brightness(104%) contrast(106%)";
      setTimeout(function(){
        document.querySelector("main").classList.remove("blackTransition");
        document.querySelector(".header").classList.remove("blackTransition");
        document.querySelector("main").classList.remove("whiteTransition");
      document.querySelector(".header").classList.remove("whiteTransition");
      },800);
    }
  });


//Jquery
$(document).ready(function () {
    const next = "<div class=\"mutanto__elements-arrow-rigth \"><i class=\"fa-solid fa-arrow-right-long\"></i></div>";
    const prev = "<div class=\"mutanto__elements-arrow-rigth\"><i class=\"fa-solid fa-arrow-left-long\"></i></div>";
    const staffPicsCards = $(".mutanto-services__staffPics");
    const windowWidth = $(window).width();

    if (windowWidth <= mobiles) {
        staffPicsCards.addClass("owl-carousel");
        staffPicsCards.owlCarousel({
            items: 1.1,
            margin: 0,
            loop: true,
            nav:true,
            navText: [prev, next],
            autoplay: true,
            center:true,
            dots:false,    
            responsiveClass:true,
            responsive:{
                300:{
                    items:1,
                    center:true,
                    margin:0,
                    nav:true,
                    navText: [prev, next],
                    center:true,
                },
                380:{
                    items:1.5,
                    center:true,
                    margin:66,
                    nav:true,
                    navText: [prev, next],
                    center:true,
                },
                500:{
                    items:1.5,
                    center:true,
                    margin:66,
                    nav:true,
                    navText: [prev, next],
                    center:true,
                },
            }
          });
    }
})
