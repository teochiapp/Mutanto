//Global Vars 
const mobiles = 579;
const tables = 1199;
const destktop = 1200
const descktop = destktop;

function getWindowWidth() {
  return window.innerWidth;
}

function getWindowHeight() {
  return window.innerHeight;
}


//SetUp height = screen Height
function setUpDivAsFullScreen(...divs) {
  const height = Math.max(document.documentElement.clientHeight);
  divs.forEach((e) => {
    e.style.height = height + 'px';
  }
  )
}